#ifdef MATLAB_MEX_FILE
#ifdef ML_PASSRNG_H

#include "ML.meal.h"

	ML_pass_runif (int nlhs, mxArray* plhs[], int nrhs, mxArray *prhs[]) ;
	ML_pass_rnorm (int nlhs, mxArray* plhs[], int nrhs, mxArray *prhs[]) ;

#endif	//	#ifdef ML_PASSRNG_H
#endif	//	#ifdef MATLAB_MEX_FILE
